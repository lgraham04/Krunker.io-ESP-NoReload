THIS WILL ONLY WORK ON GOOGLE CHROME AND CHROMIUM BASED BROWSERS EX: NEW MICROSOFT EDGE.


INSTRUCTIONS
-------------
1. Go to menu and hit More tools.
2. Then open Developer tools.
3. Then go to Sources tab.
4. Press >> and hit the Overrides tab.
5. Press + Select folder for overrides and choose /Path/To/krunker.io/
6. Press on krunker.io/js folder and open game.js
7. Now just type a space and save it using Ctrl+S (Cmd+S If on Mac).
8. Now refresh the page and you are done.
